# gift-box

 on backend
 npm install
  npm i -s express cors jsonwebtoken mysql
  npm install express bcrypt body-parser --save